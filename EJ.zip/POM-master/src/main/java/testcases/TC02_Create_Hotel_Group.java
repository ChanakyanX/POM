package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.HatsMvpWrappers;

public class TC02_Create_Hotel_Group extends HatsMvpWrappers{

	@BeforeClass
	public void startTestCase(){
		browserName 	= "chrome";
		dataSheetName 	= "HotelGroupName";
		testCaseName 	= "TC02-Create Hotel Group";
		testDescription = "Creating a Hotel Group";
	}


	@Test(dataProvider="fetchData")
	public void createHotelGroup(String HGN,String Add1,String Phone,String phoneDesc,String ContactName,String Add2,
			String Email,String Remarks,String City,
			String PostCode,String Country,String Fax) {
		new LoginPage()
		.clickLogin()
		.clickContacts()
		.clickHotel()
		.clickCreate()		
		.clickHotelGroup()
		.sendHotelGroupName(HGN)
		.sendHGAddress1(Add1)
		.sendHGPhone(Phone)
		.sendHGPhoneDesc(phoneDesc)
		.sendHGContactName(ContactName)
		.sendHGAddress2(Add2)
		.sendHGEmail(Email)
		.sendHGRemarks(Remarks)
		.sendHGCity(City)
		.sendHGPostalCode(PostCode)
		.clickHGCountry().enterHGCountry(Country).HGclickToSelectCountry()
		.HGsendFax(Fax);
		
		 

	}
}
