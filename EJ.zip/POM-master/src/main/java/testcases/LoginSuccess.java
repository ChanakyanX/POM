package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.HatsMvpWrappers;

public class LoginSuccess extends HatsMvpWrappers{
	
	@BeforeClass
	public void startTestCase(){
		browserName 	= "CHROME";
		dataSheetName 	= "TC01_Login";
		testCaseName 	= "Login Success";
		testDescription = "Login into HATS as Super User";
	}
	
	
	@Test/*(dataProvider="fetchData")*/
	public void loginSuccess() {
		new LoginPage()
		.clickLogin();
		
	}
}
