package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.HatsMvpWrappers;

public class TC05_Create_Transport_Contact extends HatsMvpWrappers{

	@BeforeClass
	public void startTestCase(){
		browserName 	= "chrome";
		dataSheetName 	= "TransportContact";
		testCaseName 	= "TC05-Create a Transport Contact";
		testDescription = "Creating a transport contact";
	}


	@Test(dataProvider="fetchData")
	public void createTransportContact(String TransportName,String Add1,String PostCode,String ContactName,String Add2,String Phone,
			String PhoneDesc,String Remarks,String City,
			String Email,String Country,String Fax) {
		new LoginPage()
		.clickLogin()
		.clickContacts()
		.clickTransport()
		.clickTransportCreate()	
		.sendTransportName(TransportName)
		.sendAddress1(Add1)
		.sendContactName(ContactName)
		.sendAddress2(Add2)
		.sendPhoneNumber(Phone).sendPhoneDesc(PhoneDesc)                                                                                                                                                      
		.sendCity(City)
		.sendEmail(Email)
		.sendPostalCode(PostCode)
		.clickToEnterCountry().enterCountry(Country).clickToSelectCountry()
		.sendFax(Fax)
		.sendRemarks(Remarks);
		/*	.clickSave();
		 */

	}
}
