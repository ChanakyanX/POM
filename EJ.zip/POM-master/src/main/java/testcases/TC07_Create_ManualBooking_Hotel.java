package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.HatsMvpWrappers;

public class TC07_Create_ManualBooking_Hotel extends HatsMvpWrappers{

	@BeforeClass
	public void startTestCase(){
		browserName 	= "chrome";
		dataSheetName 	= "ManualBookingHotel";
		testCaseName 	= "TC07-Create a manual booking - hotel";
		testDescription = "Creating a hotel manual booking";
	}


	@Test(dataProvider="fetchData")
	public void createTransportContact(String baseLoc,String DT,String CCC,String checkInDate,String checkInTime,
			String checkOutDate,String checkOutTime,String hotelName,String transReqIn,String transReqOut,String excludeDates,
			String TPBR,String adminRemarks,String supplierRemarks,
			
			String roomRate,String currency,String roomType,String noOfNights,
			String Category,String Amount,String miscRemarks,String CrewId,String ArrivalDuty,String DepartureDuty,String CrewRemarks) throws InterruptedException
		 {
		new LoginPage()
		.clickLogin()
		.clickManualBooking()
		.CreateHotelMB()
		.clickToEnterBaseLocation().enterBaseLocation(baseLoc).clickAndSelectBaseLocation()
		.clickToEnterDutyType().enterDutyType(DT).clickAndSelectDutyType()
		.clickToEnterCostCentreCategory().enterCostCentreCategory(CCC).clickAndSelectCostCentreCategory()
		.enterCheckInDate(checkInDate).enterCheckInTime(checkInTime)
		.enterCheckOutDate(checkOutDate).enterCheckOutTime(checkOutTime)
		.clickToEnterHotelName().enterHotelName(hotelName).clickAndSelectHotelName()
		.selectInTransportRequired(transReqIn).selectOutTransportRequired(transReqOut)
		//.enterExcludeDates(excludeDates)		
		.enterThirdPartyBookingReference(TPBR).enterAdminRemarks(adminRemarks).enterSupplierRemarks(supplierRemarks)
		
		.clickCostInformation()
		.enterRoomRate(roomRate)
		.clickCurrency().enterCurrency(currency).clickToSelectCurrency()
		.selectRoomType(roomType).enterNoOfNights(noOfNights)
		.selectCategory(Category).enterAmount(Amount)
		.enterMiscRemarks(miscRemarks)
		.clickCrewInfo()
		.enterCrewID(CrewId).enterArrivalDuty(ArrivalDuty).enterDepartureDuty(DepartureDuty).enterCrewRemarks(CrewRemarks)
		
		
		;
		
		/*	.clickSave();
		 */

	}
}
