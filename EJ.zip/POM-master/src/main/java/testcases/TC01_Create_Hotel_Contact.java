package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.HatsMvpWrappers;

public class TC01_Create_Hotel_Contact extends HatsMvpWrappers{

	@BeforeClass
	public void startTestCase(){
		browserName 	= "chrome";
		dataSheetName 	= "Contact";
		testCaseName 	= "TC01-Create Hotel Contact";
		testDescription = "Creating a hotel contact";
	}


	@Test(dataProvider="fetchData")
	public void createContact(String HotelName,String Add1,String ContactName,String HotelGroupName,String Add2,String Phone,
			String PhoneDesc,String BaseLocation,String City,
			String Email,String Remarks,String Country,String Fax,String PostCode,String TimeToTravel) throws InterruptedException {
		new LoginPage()
		.clickLogin()
		.clickContacts()
		.clickHotel()
		.clickCreate()		
		.sendHotelName(HotelName)
		.sendAddress1(Add1)
		.sendContactName(ContactName)
		.clickToEnterHotelGroup()
		.enterHotelGroupName(HotelGroupName)
		.sendAddress2(Add2)
		.clickAndSelectHotelGroupName()
		.sendPhoneNumber(Phone).sendPhoneDesc(PhoneDesc)                                                                                                                                                      
		.clickToEnterBaseLoc().enterBaseLoc(BaseLocation).clickToSelectBaseLoc()
		.sendCity(City)
		.sendEmail(Email)
		.sendPostalCode(PostCode)
		.clickToEnterCountry().enterCountry(Country).clickToSelectCountry()
		.sendFax(Fax)
		.sendRemarks(Remarks)
		.sendTimeToTravel(TimeToTravel)
		.clickSave()
		.verifyContactCreated(HotelName);
		

	}
}
