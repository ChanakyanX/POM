package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.HatsMvpWrappers;

public class TC08_Create_ManualBooking_Transport extends HatsMvpWrappers{

	@BeforeClass
	public void startTestCase(){
		browserName 	= "chrome";
		dataSheetName 	= "ManualBookingTransport";
		testCaseName 	= "TC08-Create a manual booking - Transport";
		testDescription = "Creating a hotel contract";
	}


	@Test(dataProvider="fetchData")
	public void createHotelContract(String pickUpLoc,String pickUpDate,String pickUpTime,String dropOffLoc,String dropOffDate,String dropOffTime,
			String transportName,String dutyType,String costCentreCategory,String vehicleType,String waitingTime,String thirdPartyBookingRef,
			String internalRemarks,String supplierRemarks,String excessBaggage,
			
			String rate,String currency,
			String Category,String charge,String miscRemarks,
			
			String CrewId,String pickUpPoint,String dropOffPoint,String pickUpActivity,String dropOffActivity,String crewRemarks) throws InterruptedException
		 {
		new LoginPage()
		.clickLogin()
		.clickManualBooking()
		.CreateTransportMB()
		.clickToEnterPickUpLoc().enterPickUpLoc(pickUpLoc).clickAndSelectPickUpLoc()
		.enterPickUpDate(pickUpDate).enterPickUpTime(pickUpTime)
		.clickToEnterDropOffLoc().enterDropOffLoc(dropOffLoc).clickAndSelectDropOffLoc()
		//.enterDropOffDate(dropOffDate)
		.enterDropOffTime(dropOffTime)
		.clickToEnterTransportlName().enterTransportName(transportName).clickAndSelectTransportName()
		.clickToEnterDutyType().enterDutyType(dutyType).clickAndSelectDutyType()
		.clickToEnterCostCentreCategory().enterCostCentreCategory(costCentreCategory).clickAndSelectCostCentreCategory()
		.clickToEnterVehicleType().enterVehicleType(vehicleType).clickAndSelectVehicleType()
		.enterWaitingTime(waitingTime).enterThirdPartyBookingRef(thirdPartyBookingRef).enterInternalRemarks(internalRemarks)
		.enterSupplierRemarks(supplierRemarks).checkExcessBaggage(excessBaggage)
		.clickCostInfo().enterRate(rate)
		.clickCurrency().enterCurrency(currency).selectCurrency()
		.selectCategory(Category).enterCharge(charge)
		.enterRemarks(miscRemarks)
		.clickCrewInfo()
		.enterCrewId(CrewId).enterPickUpPoint(pickUpPoint).enterDropOffPoint(dropOffPoint).enterPickUpActivity(pickUpActivity)
		.enterDropOffActivity(dropOffActivity).enterCrewRemarks(crewRemarks)
		
		;
		
		/*	.clickSave();
		 */

	}
}
