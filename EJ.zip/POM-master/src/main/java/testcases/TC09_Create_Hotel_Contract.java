package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.HatsMvpWrappers;

public class TC09_Create_Hotel_Contract extends HatsMvpWrappers{

	@BeforeClass
	public void startTestCase(){
		browserName 	= "chrome";
		dataSheetName 	= "ManualBookingTransport";
		testCaseName 	= "TC08-Create a manual booking - Transport";
		testDescription = "Creating a transport manual booking" ;
	}


	@Test(dataProvider="fetchData")
	public void createHotelContract(String hotelName,String roomCap,String contractStartDate,String contractEndDate,String sourceProvider, String commercialNightStops,
			String checkinType,String checkinTime,String checkoutTime,String standardRoomRate,String twinRoomRate,String currencyCode,
			String hoteltransportStartTime,String hoteltransportEndTime,
			String category,String Amount,
			String Remarks,String ContractDescription) throws InterruptedException
		 {
		new LoginPage()
		.clickLogin()          
		.clickContract()       
		.clickHotelContract()
		.clickHotelContractCreate()
		.sendHotelName(hotelName)
		.selectHotel()
		.sendRoomCap(roomCap)
		.sendContractStartDate(contractStartDate)
		.sendContractEndDate(contractEndDate)
		.clickSourceProvider()
		.sendSourceProvider(sourceProvider)
		.selectSourceProvider()
		.checkCommercialNightStop(commercialNightStops)
		.selectCheckinType()
		.sendStandardRoomRate(standardRoomRate)
		.sendTwinRoomRate(twinRoomRate)
		.sendCurrency(currencyCode)
		.selectHotelTransportReq(hoteltransportStartTime,hoteltransportStartTime)
		.selectCategory(category)
		.sendAmount(Amount)
		.sendRemarks(Remarks)
		.sendContractDescription(ContractDescription)
		.clickSave()
		.verifyHotelContract(hotelName, contractStartDate, contractEndDate);
			
	
	}
}
