package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.HatsMvpWrappers;

public class TC06_Create_Transport_Third_Party extends HatsMvpWrappers{

	@BeforeClass
	public void startTestCase(){
		browserName 	= "chrome";
		dataSheetName 	= "TransportContact";
		testCaseName 	= "TC06-Create a Transport-Third Party";
		testDescription = "Creating a transport-third party contact";
	}


	@Test(dataProvider="fetchData")
	public void createTransportContact(String TransportName,String Add1,String PostCode,String ContactName,String Add2,String Phone,
			String PhoneDesc,String Remarks,String City,
			String Email,String Country,String Fax) {
		new LoginPage()
		.clickLogin()
		.clickContacts()
		.clickTransport()
		.clickTransportCreate()	
		.TPclickThirdParty()
		.TPsendTransportName(TransportName)
		.TPsendAddress1(Add1)
		.TPsendContactName(ContactName)
		.TPsendAddress2(Add2)
		.TPsendPhoneNumber(Phone).TPsendPhoneDesc(PhoneDesc)                                                                                                                                                      
		.TPsendCity(City)
		.TPsendEmail(Email)
		.TPsendPostalCode(PostCode)
		.TPclickToEnterCountry().TPenterCountry(Country).TPclickToSelectCountry()
		.TPsendFax(Fax)
		.TPsendRemarks(Remarks);
		/*	.clickSave();
		 */

	}
}
