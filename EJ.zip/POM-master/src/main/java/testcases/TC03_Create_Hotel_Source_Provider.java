package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.HatsMvpWrappers;

public class TC03_Create_Hotel_Source_Provider extends HatsMvpWrappers{

	@BeforeClass
	public void startTestCase(){
		browserName 	= "chrome";
		dataSheetName 	= "SourceProviderName";
		testCaseName 	= "TC03-Create Hotel Source Provider";
		testDescription = "Creating a Source Provider";
	}


	@Test(dataProvider="fetchData")
	public void createHotelSourceProvider(String SPN,String Add1,String Phone,String phoneDesc,String ContactName,String Add2,
			String Email,String Remarks,String City,
			String PostCode,String Country,String Fax) {
		new LoginPage()
		.clickLogin()
		.clickContacts()
		.clickHotel()
		.clickCreate()		
		.clickSourceProvider()
		.sendSourceProviderName(SPN)
		.sendSPAddress1(Add1)
		.sendSPPhone(Phone)
		.sendSPPhoneDesc(phoneDesc)
		.sendSPContactName(ContactName)
		.sendSPAddress2(Add2)
		.sendSPEmail(Email)
		.sendSPRemarks(Remarks)
		.sendSPCity(City)
		.sendSPPostalCode(PostCode)
		.clickSPCountry().enterSPCountry(Country).SPclickToSelectCountry()
		.SPsendFax(Fax);
		/*	.clickSave();
		 */

	}
}
