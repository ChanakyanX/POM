package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.HatsMvpWrappers;

public class TC04_Create_Hotel_Third_Party extends HatsMvpWrappers{

	@BeforeClass
	public void startTestCase(){
		browserName 	= "chrome";
		dataSheetName 	= "ThirdParty";
		testCaseName 	= "TC04-Create Hotel Third Party";
		testDescription = "Creating a Hotel Third Party";
	}


	@Test(dataProvider="fetchData")
	public void createHotelThirdParty(String TPHN,String Add1,String Phone,String phoneDesc,String ContactName,String Add2,
			String Email,String BaseLocation,String Remarks,String City,
			String PostCode,String Country,String Fax) {
		new LoginPage()
		.clickLogin()
		.clickContacts()
		.clickHotel()
		.clickCreate()		
		.clickThirdParty()
		.sendThirdPartyName(TPHN)
		.sendTPAddress1(Add1)
		.sendTPPhone(Phone)
		.sendTPPhoneDesc(phoneDesc)
		.sendTPContactName(ContactName)
		.sendTPAddress2(Add2)
		.sendTPEmail(Email)
		.TPclickToEnterBaseLoc().TPenterBaseLoc(BaseLocation).TPclickToSelectBaseLoc()
		.sendTPRemarks(Remarks)
		.sendTPCity(City)
		.sendTPPostalCode(PostCode)
		.clickTPCountry().enterTPCountry(Country).TPclickToSelectCountry()
		.TPsendFax(Fax);
		/*	.clickSave();
		 */

	}
}
