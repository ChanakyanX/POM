package pages;



import java.awt.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import wrappers.HatsMvpWrappers;

public class ManualBookingTransport extends HatsMvpWrappers{

	// Manual Booking - Transport - Create 

	public ManualBookingTransport clickToEnterPickUpLoc(){
		clickByXpath(prop.getProperty("MB.T.PickUpLocation.Click"));	
		return this;
	}
	public ManualBookingTransport enterPickUpLoc(String pickUpLoc){	
		enterTextByXpath(prop.getProperty("MB.T.PickUpLocation.Enter"),pickUpLoc);		
		return this;
	}
	public ManualBookingTransport clickAndSelectPickUpLoc(){
		clickByXpath(prop.getProperty("MB.T.PickUpLocation.Select"));
		return this;
	}

	public ManualBookingTransport enterPickUpDate(String pickUpDate) throws InterruptedException{
		Thread.sleep(2000);
		enterTextByXpath(prop.getProperty("MB.T.PickUpDate"),pickUpDate);
		return this;
	}
	public ManualBookingTransport enterPickUpTime(String pickUpTime){
		enterTextByXpath(prop.getProperty("MB.T.LocalPickUpTime"),pickUpTime);
		return this;
	}
	public ManualBookingTransport clickToEnterDropOffLoc(){
		clickByXpath(prop.getProperty("MB.T.DropOffLocation.Click"));	
		return this;
	}
	public ManualBookingTransport enterDropOffLoc(String dropOffLoc){	
		enterTextByXpath(prop.getProperty("MB.T.DropOffLocation.Enter"),dropOffLoc);		
		return this;
	}
	public ManualBookingTransport clickAndSelectDropOffLoc(){
		clickByXpath(prop.getProperty("MB.T.DropOffLocation.Select"));
		return this;
	}
	public ManualBookingTransport enterDropOffDate(String dropOffDate) throws InterruptedException{
		Thread.sleep(2000);
		enterTextByXpath(prop.getProperty("MB.T.DropOffDate"),dropOffDate);
		return this;
	}
	public ManualBookingTransport enterDropOffTime(String dropOffTime) throws InterruptedException{
		///Thread.sleep(2000);
		enterTextByXpath(prop.getProperty("MB.T.LocalDropOffTime"),dropOffTime);
		return this;
	}
	public ManualBookingTransport clickToEnterTransportlName(){
		clickByXpath(prop.getProperty("MB.T.TransportName.Click"));	
		return this;
	}
	public ManualBookingTransport enterTransportName(String hotelName){	
		enterTextByXpath(prop.getProperty("MB.T.TransportName.Enter"),hotelName);		
		return this;
	}
	public ManualBookingTransport clickAndSelectTransportName(){
		clickByXpath(prop.getProperty("MB.T.TransportName.Select"));
		return this;
	}
	public ManualBookingTransport clickToEnterDutyType(){
		clickByXpath(prop.getProperty("MB.T.DutyType.Click"));
		return this;
	}
	public ManualBookingTransport enterDutyType(String DT) throws InterruptedException{
		enterTextByXpath(prop.getProperty("MB.T.DutyType.Enter"),DT);
		return this;
	}
	public ManualBookingTransport clickAndSelectDutyType() throws InterruptedException{
		clickByXpath(prop.getProperty("MB.T.DutyType.Select"));	
		return this;
	}
	public ManualBookingTransport clickToEnterCostCentreCategory() throws InterruptedException{
		clickByXpath(prop.getProperty("MB.T.CostCentreCategory.Click"));
		return this;
	}
	public ManualBookingTransport enterCostCentreCategory(String CCC) throws InterruptedException{
		enterTextByXpath(prop.getProperty("MB.T.CostCentreCategory.Enter"),CCC);
		Thread.sleep(1000);
		return this;
	}
	public ManualBookingTransport clickAndSelectCostCentreCategory() throws InterruptedException{
		clickByXpath(prop.getProperty("MB.T.CostCentreCategory.Select"));
		return this;
	}
	public ManualBookingTransport clickToEnterVehicleType(){
		clickByXpath(prop.getProperty("MB.T.VehicleType.Click"));
		return this;
	}
	public ManualBookingTransport enterVehicleType(String DT) throws InterruptedException{
		enterTextByXpath(prop.getProperty("MB.T.VehicleType.Enter"),DT);
		return this;
	}
	public ManualBookingTransport clickAndSelectVehicleType() throws InterruptedException{
		clickByXpath(prop.getProperty("MB.T.VehicleType.Select"));	
		return this;
	}
	public ManualBookingTransport ewait() throws InterruptedException{
		explicitWait();
		return this;
	}
	public ManualBookingTransport enterWaitingTime(String WT){		
		enterTextByXpath(prop.getProperty("MB.T.WaitingTime"),WT);
		return this;
	}
	public ManualBookingTransport enterThirdPartyBookingRef(String TPBR){
		enterTextByXpath(prop.getProperty("MB.T.ThirdPartyBookingRef"),TPBR);
		return this;
	}
	public ManualBookingTransport enterInternalRemarks(String internalRemarks){
		enterTextByXpath(prop.getProperty("MB.T.InternalRemarks"),internalRemarks);
		return this;
	}
	public ManualBookingTransport enterSupplierRemarks(String supplierRemarks){
		enterTextByXpath(prop.getProperty("MB.T.RemarksToSupplier"),supplierRemarks);
		return this;
	}
	public ManualBookingTransport checkExcessBaggage(String excessBaggage){
		if(excessBaggage.equalsIgnoreCase("y")){
			clickByXpath(prop.getProperty("MB.T.ExcessBaggage"));			
		}
		return this;
	}
	public ManualBookingTransport clickCostInfo(){
		clickByXpath(prop.getProperty("MB.T.CostInfo.Click"));
		return this;
	}
	public ManualBookingTransport enterRate(String rate){
		enterTextByXpath(prop.getProperty("MB.T.Rate"),rate);
		return this;
	}
	public ManualBookingTransport clickCurrency(){
		clickByXpath(prop.getProperty("MB.T.Currency.Click"));
		return this;
	}
	public ManualBookingTransport enterCurrency(String currency){
		enterTextByXpath(prop.getProperty("MB.T.Currency.Send"),currency);
		return this;
	}
	public ManualBookingTransport selectCurrency(){
		clickByXpath(prop.getProperty("MB.T.Currency.Select"));
		return this;
	}
	
	public ManualBookingTransport selectCategory(String value){
		selectByxPath(prop.getProperty("MB.T.Category"),value);
		return this;
	}
	public ManualBookingTransport enterCharge(String charge){		
		enterTextByXpath(prop.getProperty("MB.T.Charge"),charge);
		return this;
	}
	public ManualBookingTransport enterRemarks(String remarks){		
		enterTextByXpath(prop.getProperty("MB.T.Remarks"),remarks);
		return this;
	}
	public ManualBookingTransport clickCrewInfo(){
		clickByXpath(prop.getProperty("MB.T.CrewInformation.Click"));
		return this;
	}
	public ManualBookingTransport enterCrewId(String crewId) throws InterruptedException{		
		enterTextByXpath(prop.getProperty("MB.T.CrewID.Enter"),crewId);
		Thread.sleep(1000);
		return this;
	}
	public ManualBookingTransport enterPickUpPoint(String pickUpPoint){		
		enterTextByXpath(prop.getProperty("MB.T.PickUpPoint"),pickUpPoint);
		return this;
	}
	public ManualBookingTransport enterDropOffPoint(String dropOffPoint){		
		enterTextByXpath(prop.getProperty("MB.T.DropOffPoint"),dropOffPoint);
		return this;
	}
	public ManualBookingTransport enterPickUpActivity(String pickUpActivity){		
		enterTextByXpath(prop.getProperty("MB.T.PickUpActivity"),pickUpActivity);
		return this;
	}
	public ManualBookingTransport enterDropOffActivity(String dropOffPoint){		
		enterTextByXpath(prop.getProperty("MB.T.DropOffActivity"),dropOffPoint);
		return this;
	}
	public ManualBookingTransport enterCrewRemarks(String crewRemarks){		
		enterTextByXpath(prop.getProperty("MB.T.RemarksToCrew"),crewRemarks);
		return this;
	}
	
	
	public ManualBookingTransport clickSave(){
		clickByXpath(prop.getProperty("MB.T.Save.Click"));
		return this;
	}


	/*-----------------------------------------End of Create Hotel------------------------------------------------------------------------------*/	


}






