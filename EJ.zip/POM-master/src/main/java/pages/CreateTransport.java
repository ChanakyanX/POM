package pages;

import wrappers.HatsMvpWrappers;

public class CreateTransport extends HatsMvpWrappers{

	// Create Transport Actions

	public CreateTransport sendTransportName(String transportName){
		enterTextByXpath(prop.getProperty("TContact.Enter.TName"),transportName);		
		return this;
	}
	public CreateTransport sendAddress1(String address1){
		enterTextByXpath(prop.getProperty("TContact.Enter.Add1"),address1);		
		return this;
	}
	public CreateTransport sendPostalCode(String pCode){
		enterTextByXpath(prop.getProperty("TContact.Enter.PostCode"),pCode);		
		return this;
	}
	public CreateTransport sendContactName(String cName){
		enterTextByXpath(prop.getProperty("TContact.Enter.ContactName"),cName);		
		return this;
	}
	public CreateTransport sendAddress2(String address2){
		enterTextByXpath(prop.getProperty("TContact.Enter.Add2"),address2);		
		return this;
	}

	public CreateTransport sendPhoneNumber(String phNum){
		enterTextByXpath(prop.getProperty("TContact.Enter.Phone"),phNum);		
		return this;
	}
	public CreateTransport sendPhoneDesc(String phoneDesc){
		enterTextByXpath(prop.getProperty("TContact.Enter.PhoneDesc"),phoneDesc);		
		return this;
	}
	public CreateTransport sendRemarks(String remarks){
		enterTextByXpath(prop.getProperty("TContact.Enter.Remarks"),remarks);		
		return this;
	}

	public CreateTransport sendCity(String city){
		enterTextByXpath(prop.getProperty("TContact.Enter.City"),city);		
		return this;
	}
	public CreateTransport sendEmail(String email){
		enterTextByXpath(prop.getProperty("TContact.Enter.Email"),email);		
		return this;
	}

	public CreateTransport clickToEnterCountry(){
		clickByXpath(prop.getProperty("TContact.Click.Country"));		
		return this;
	}	
	public CreateTransport enterCountry(String country){
		enterTextByXpath(prop.getProperty("TContact.Enter.Country"), country);
		return this;
	}	
	public CreateTransport clickToSelectCountry(){	
		clickByXpath(prop.getProperty("TContact.Select.Country"));		
		return this;
	}
	public CreateTransport sendFax(String fax){
		enterTextByXpath(prop.getProperty("TContact.Enter.Fax"),fax);		
		return this;
	}

	public CreateTransport clickSave(){
		clickByXpath(prop.getProperty("TContact.Click.Save"));
		return this;
	}


	/*-----------------------------------------End of Create Hotel------------------------------------------------------------------------------*/	
	// Third Party Actions

	
	public CreateTransport TPclickThirdParty(){
		clickByLink(prop.getProperty("TContact.Click.ThirdParty"));
		return this;		
	}

	public CreateTransport TPsendTransportName(String transportName){
		enterTextByXpath(prop.getProperty("TContact.Enter.TP.TName"),transportName);		
		return this;
	}
	public CreateTransport TPsendAddress1(String address1){
		enterTextByXpath(prop.getProperty("TContact.Enter.TP.Add1"),address1);		
		return this;
	}
	public CreateTransport TPsendPostalCode(String pCode){
		enterTextByXpath(prop.getProperty("TContact.Enter.TP.PostCode"),pCode);		
		return this;
	}
	public CreateTransport TPsendContactName(String cName){
		enterTextByXpath(prop.getProperty("TContact.Enter.TP.ContactName"),cName);		
		return this;
	}
	public CreateTransport TPsendAddress2(String address2){
		enterTextByXpath(prop.getProperty("TContact.Enter.TP.Add2"),address2);		
		return this;
	}

	public CreateTransport TPsendPhoneNumber(String phNum){
		enterTextByXpath(prop.getProperty("TContact.Enter.TP.Phone"),phNum);		
		return this;
	}
	public CreateTransport TPsendPhoneDesc(String phoneDesc){
		enterTextByXpath(prop.getProperty("TContact.Enter.TP.PhoneDesc"),phoneDesc);		
		return this;
	}
	public CreateTransport TPsendRemarks(String remarks){
		enterTextByXpath(prop.getProperty("TContact.Enter.TP.Remarks"),remarks);		
		return this;
	}

	public CreateTransport TPsendCity(String city){
		enterTextByXpath(prop.getProperty("TContact.Enter.TP.City"),city);		
		return this;
	}
	public CreateTransport TPsendEmail(String email){
		enterTextByXpath(prop.getProperty("TContact.Enter.TP.Email"),email);		
		return this;
	}

	public CreateTransport TPclickToEnterCountry(){
		clickByXpath(prop.getProperty("TContact.Click.TP.Country"));		
		return this;
	}	
	public CreateTransport TPenterCountry(String country){
		enterTextByXpath(prop.getProperty("TContact.Enter.TP.Country"), country);
		return this;
	}	
	public CreateTransport TPclickToSelectCountry(){	
		clickByXpath(prop.getProperty("TContact.Select.TP.Country"));		
		return this;
	}
	public CreateTransport TPsendFax(String fax){
		enterTextByXpath(prop.getProperty("TContact.Enter.TP.Fax"),fax);		
		return this;
	}

	public CreateTransport TPclickSave(){
		clickByXpath(prop.getProperty("TContact.Click.TP.Save"));
		return this;
	}	
}






