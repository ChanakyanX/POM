package pages;



import wrappers.HatsMvpWrappers;

public class CreateHotel extends HatsMvpWrappers{

	// Create Hotel Actions

	public CreateHotel sendHotelName(String hotelName){
		enterTextByXpath(prop.getProperty("Contact.Enter.HotelName"),hotelName);		
		return this;
	}
	public CreateHotel sendAddress1(String address1){
		enterTextByXpath(prop.getProperty("Contact.Enter.Address1"),address1);		
		return this;
	}
	public CreateHotel sendContactName(String cName){
		enterTextByXpath(prop.getProperty("Contact.Enter.ContactName"),cName);		
		return this;
	}
	public CreateHotel clickToEnterHotelGroup(){
		clickByXpath(prop.getProperty("Contact.Click.HotelGroupName"));
		return this;
	}
	public CreateHotel enterHotelGroupName(String HGN){
		enterTextByXpath(prop.getProperty("Contact.Send.HotelGroupName"),HGN );

		return this;
	}
	public CreateHotel clickAndSelectHotelGroupName(){
		clickByXpath(prop.getProperty("Contact.Select.HotelGroupName"));		
		return this;
	}
	public CreateHotel sendAddress2(String address2){
		enterTextByXpath(prop.getProperty("Contact.Enter.Address2"),address2);		
		return this;
	}
	public CreateHotel sendPhoneNumber(String phNum){
		enterTextByXpath(prop.getProperty("Contact.Enter.PhoneNumber"),phNum);		
		return this;
	}
	public CreateHotel sendPhoneDesc(String phoneDesc){
		enterTextByXpath(prop.getProperty("Contact.Enter.PhoneDesc"),phoneDesc);		
		return this;
	}
	public CreateHotel clickToEnterBaseLoc(){
		clickByXpath(prop.getProperty("Contact.Click.BaseLocation"));
		return this;
	}
	public CreateHotel enterBaseLoc(String baseLoc){
		enterTextByXpath(prop.getProperty("Contact.Send.BaseLocation"),baseLoc);
		return this;
	}
	public CreateHotel clickToSelectBaseLoc(){
		clickByXpath(prop.getProperty("Contact.Select.BaseLocation"));
		return this;
	}	
	public CreateHotel sendCity(String city){
		enterTextByXpath(prop.getProperty("Contact.Send.City"),city);		
		return this;
	}
	public CreateHotel sendEmail(String email){
		enterTextByXpath(prop.getProperty("Contact.Send.Email"),email);		
		return this;
	}
	public CreateHotel sendRemarks(String remarks){
		enterTextByXpath(prop.getProperty("Contact.Send.Remarks"),remarks);		
		return this;
	}
	public CreateHotel clickToEnterCountry(){
		clickByXpath(prop.getProperty("Contact.Click.Country"));		
		return this;
	}	
	public CreateHotel enterCountry(String country){
		enterTextByXpath(prop.getProperty("Contact.Send.Country"), country);
		/*WebDriverWait wait = new WebDriverWait(driver, 15);
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='hot_create']/div/div[1]/div[3]/div/span/div/div[2]/div/div/label/span")));*/
		return this;
	}	
	public CreateHotel clickToSelectCountry(){	
		clickByXpath(prop.getProperty("Contact.Select.Country"));		
		return this;
	}
	public CreateHotel sendFax(String fax){
		enterTextByXpath(prop.getProperty("Contact.Send.Fax"),fax);		
		return this;
	}
	public CreateHotel sendPostalCode(String pCode){
		enterTextByXpath(prop.getProperty("Contact.Send.PostCode"),pCode);		
		return this;
	}
	public CreateHotel sendTimeToTravel(String TtT){
		enterTextByXpath(prop.getProperty("Contact.Send.TimeToTravel"),TtT);		
		return this;
	}
	public CreateHotel clickSave() throws InterruptedException{
		clickByXpath(prop.getProperty("Contact.Click.Save"));
		Thread.sleep(2000);
		return this;
	}

	public CreateHotel verifyContactCreated(String text){
		verifyHotelContact(text);

		return this;

	}

	/*-----------------------------------------End of Create Hotel------------------------------------------------------------------------------*/	
	// Hotel Group Actions

	public CreateHotel clickHotelGroup(){
		clickByLink(prop.getProperty("HG.Contact.Click.HotelGroup"));
		return this;
	}
	public CreateHotel sendHotelGroupName(String HGN){
		enterTextByXpath(prop.getProperty("HGContact.Enter.HotelGroupName"),HGN);		
		return this;
	}
	public CreateHotel sendHGAddress1(String address1){
		enterTextByXpath(prop.getProperty("HGContact.Enter.Address1"),address1);		
		return this;
	}
	public CreateHotel sendHGPhone(String Phone){
		enterTextByXpath(prop.getProperty("HGContact.Enter.Phone"),Phone);		
		return this;
	}
	public CreateHotel sendHGPhoneDesc(String phoneDesc){
		enterTextByXpath(prop.getProperty("HGContact.Enter.PhoneDesc"),phoneDesc);
		return this;
	}
	public CreateHotel sendHGContactName(String cName){
		enterTextByXpath(prop.getProperty("HGContact.Enter.ContactName"),cName );

		return this;
	}
	public CreateHotel sendHGAddress2(String address2){
		enterTextByXpath(prop.getProperty("HGContact.Enter.Address2"),address2);		
		return this;
	}
	public CreateHotel sendHGEmail(String Email){
		enterTextByXpath(prop.getProperty("HGContact.Enter.Email"),Email);		
		return this;
	}
	public CreateHotel sendHGRemarks(String remarks){
		enterTextByXpath(prop.getProperty("HGContact.Enter.Remarks"),remarks);
		return this;
	}
	public CreateHotel sendHGCity(String city){
		enterTextByXpath(prop.getProperty("HGContact.Enter.City"),city);		
		return this;
	}

	public CreateHotel sendHGPostalCode(String pCode){
		enterTextByXpath(prop.getProperty("HGContact.Enter.Postcode"),pCode);		
		return this;
	}

	public CreateHotel clickHGCountry(){
		clickByXpath(prop.getProperty("HGContact.Click.Country"));
		return this;
	}
	public CreateHotel enterHGCountry(String country){
		enterTextByXpath(prop.getProperty("HGContact.Send.Country"), country);
		return this;
	}	
	public CreateHotel HGclickToSelectCountry(){	
		clickByXpath(prop.getProperty("HGContact.Select.Country"));		
		return this;
	}

	public CreateHotel HGsendFax(String fax){
		enterTextByXpath(prop.getProperty("HGContact.Enter.Fax"),fax);		
		return this;
	}
	public CreateHotel HGclickSave(){
		clickByXpath(prop.getProperty("HGContact.Click.Save"));
		return this;
	}

	/*-----------------------------------------End of Create Hotel Group------------------------------------------------------------------------------*/
	// Source Provider Actions

	public CreateHotel clickSourceProvider(){
		clickByLink(prop.getProperty("SP.Contact.Click.SorceProvider"));
		return this;
	}
	public CreateHotel sendSourceProviderName(String SPN){
		enterTextByXpath(prop.getProperty("SP.Enter.SourceProviderName"),SPN);		
		return this;
	}
	public CreateHotel sendSPAddress1(String spAddr1){
		enterTextByXpath(prop.getProperty("SP.Enter.Address1"),spAddr1);		
		return this;
	}
	public CreateHotel sendSPPhone(String spPhone){
		enterTextByXpath(prop.getProperty("SP.Enter.Phone"),spPhone);		
		return this;
	}
	public CreateHotel sendSPPhoneDesc(String spphoneDesc){
		enterTextByXpath(prop.getProperty("SP.Enter.PhoneDesc"),spphoneDesc);
		return this;
	}
	public CreateHotel sendSPContactName(String spCName){
		enterTextByXpath(prop.getProperty("SP.Enter.ContactName"),spCName );
		return this;
	}
	public CreateHotel sendSPAddress2(String spAddr2){
		enterTextByXpath(prop.getProperty("SP.Enter.Address2"),spAddr2);		
		return this;
	}
	public CreateHotel sendSPEmail(String spEmail){
		enterTextByXpath(prop.getProperty("SP.Enter.Email"),spEmail);		
		return this;
	}
	public CreateHotel sendSPRemarks(String spRemarks){
		enterTextByXpath(prop.getProperty("SP.Enter.Remarks"),spRemarks);
		return this;
	}
	public CreateHotel sendSPCity(String spCity){
		enterTextByXpath(prop.getProperty("SP.Enter.City"),spCity);		
		return this;
	}

	public CreateHotel sendSPPostalCode(String spPostalCode){
		enterTextByXpath(prop.getProperty("SP.Enter.Postcode"),spPostalCode);		
		return this;
	}

	public CreateHotel clickSPCountry(){
		clickByXpath(prop.getProperty("SP.Click.Country"));
		return this;
	}
	public CreateHotel enterSPCountry(String spCountry){
		enterTextByXpath(prop.getProperty("SP.Send.Country"), spCountry);
		return this;
	}	
	public CreateHotel SPclickToSelectCountry(){	
		clickByXpath(prop.getProperty("SP.Select.Country"));		
		return this;
	}

	public CreateHotel SPsendFax(String spFax){
		enterTextByXpath(prop.getProperty("SP.Enter.Fax"),spFax);		
		return this;
	}
	public CreateHotel SPclickSave(){
		clickByXpath(prop.getProperty("SP.Click.Save"));
		return this;
	}

	/*-----------------------------------------End of Create Hotel Source Provider------------------------------------------------------------------------------*/	
	//Create Hotel Third Party 

	public CreateHotel clickThirdParty(){
		clickByLink(prop.getProperty("H.TP.Click.ThirdParty"));
		return this;
	}
	public CreateHotel sendThirdPartyName(String SPN){
		enterTextByXpath(prop.getProperty("H.TP.Enter.ThirdPartyHotelName"),SPN);		
		return this;
	}
	public CreateHotel sendTPAddress1(String spAddr1){
		enterTextByXpath(prop.getProperty("H.TP.Enter.Address1"),spAddr1);		
		return this;
	}
	public CreateHotel sendTPPhone(String spPhone){
		enterTextByXpath(prop.getProperty("H.TP.Enter.Phone"),spPhone);		
		return this;
	}
	public CreateHotel sendTPPhoneDesc(String spphoneDesc){
		enterTextByXpath(prop.getProperty("H.TP.Enter.PhoneDesc"),spphoneDesc);
		return this;
	}
	public CreateHotel sendTPContactName(String spCName){
		enterTextByXpath(prop.getProperty("H.TP.Enter.ContactName"),spCName );
		return this;
	}
	public CreateHotel sendTPAddress2(String spAddr2){
		enterTextByXpath(prop.getProperty("H.TP.Enter.Address2"),spAddr2);		
		return this;
	}
	public CreateHotel sendTPEmail(String spEmail){
		enterTextByXpath(prop.getProperty("H.TP.Enter.Email"),spEmail);		
		return this;
	}
	public CreateHotel TPclickToEnterBaseLoc(){
		clickByXpath(prop.getProperty("H.TP.Click.BaseLocation"));
		return this;
	}
	public CreateHotel TPenterBaseLoc(String baseLoc){
		enterTextByXpath(prop.getProperty("H.TP.Send.BaseLocation"),baseLoc);
		return this;
	}
	public CreateHotel TPclickToSelectBaseLoc(){
		clickByXpath(prop.getProperty("H.TP.Select.BaseLocation"));
		return this;
	}	
	public CreateHotel sendTPRemarks(String spRemarks){
		enterTextByXpath(prop.getProperty("H.TP.Enter.Remarks"),spRemarks);
		return this;
	}
	public CreateHotel sendTPCity(String spCity){
		enterTextByXpath(prop.getProperty("H.TP.Enter.City"),spCity);		
		return this;
	}
	public CreateHotel sendTPPostalCode(String spPostalCode){
		enterTextByXpath(prop.getProperty("H.TP.Enter.Postcode"),spPostalCode);		
		return this;
	}
	public CreateHotel clickTPCountry(){
		clickByXpath(prop.getProperty("H.TP.Click.Country"));
		return this;
	}
	public CreateHotel enterTPCountry(String spCountry){
		enterTextByXpath(prop.getProperty("H.TP.Send.Country"), spCountry);
		return this;
	}	
	public CreateHotel TPclickToSelectCountry(){	
		clickByXpath(prop.getProperty("H.TP.Select.Country"));		
		return this;
	}

	public CreateHotel TPsendFax(String spFax){
		enterTextByXpath(prop.getProperty("H.TP.Enter.Fax"),spFax);		
		return this;
	}
	public CreateHotel TPclickSave(){
		clickByXpath(prop.getProperty("H.TP.Click.Save"));
		return this;
	}


}






