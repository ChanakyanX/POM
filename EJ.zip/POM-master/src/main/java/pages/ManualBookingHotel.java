package pages;



import java.awt.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import wrappers.HatsMvpWrappers;

public class ManualBookingHotel extends HatsMvpWrappers{

	// Manual Booking - Hotel - Create 

	public ManualBookingHotel clickToEnterBaseLocation(){
			clickByXpath(prop.getProperty("MB.H.Click.BaseLocation"));	
		return this;
	}
	public ManualBookingHotel enterBaseLocation(String baseLoc){	
		enterTextByXpath(prop.getProperty("MB.H.Enter.BaseLocation"),baseLoc);		
		return this;
	}
	public ManualBookingHotel clickAndSelectBaseLocation(){
		clickByXpath(prop.getProperty("MB.H.Select.BaseLocation"));
		return this;
	}
	public ManualBookingHotel clickToEnterDutyType(){
		clickByXpath(prop.getProperty("MB.H.Click.DutyType"));
		return this;
	}
	public ManualBookingHotel enterDutyType(String DT) throws InterruptedException{
		enterTextByXpath(prop.getProperty("MB.H.Enter.DutyType"),DT);
		return this;
	}
	public ManualBookingHotel clickAndSelectDutyType() throws InterruptedException{
		clickByXpath(prop.getProperty("MB.H.Select.DutyType"));	
		return this;
	}

	public ManualBookingHotel clickToEnterCostCentreCategory() throws InterruptedException{
		clickByXpath(prop.getProperty("MB.H.Click.CostCentreCategory"));
		return this;
	}
	public ManualBookingHotel enterCostCentreCategory(String CCC) throws InterruptedException{
		enterTextByXpath(prop.getProperty("MB.H.Enter.CostCentreCategory"),CCC);
		return this;
	}
	public ManualBookingHotel clickAndSelectCostCentreCategory() throws InterruptedException{
		clickByXpath(prop.getProperty("MB.H.Select.CostCentreCategory"));
		return this;
	}

	
	public ManualBookingHotel ewait() throws InterruptedException{

		explicitWait();
		return this;
	}
	public ManualBookingHotel enterCheckInDate(String checkInDate) throws InterruptedException{

		Thread.sleep(2000);
		enterTextByXpath(prop.getProperty("MB.H.sendCheckInDate"),checkInDate);

		return this;
	}
	public ManualBookingHotel enterCheckInTime(String checkInTime){

		enterTextByXpath(prop.getProperty("MB.H.CheckInTime"),checkInTime);
		return this;
	}

	public ManualBookingHotel enterCheckOutDate(String checkOutDate) throws InterruptedException{

		Thread.sleep(2000);
		enterTextByXpath(prop.getProperty("MB.H.sendCheckOutDate"),checkOutDate);
		return this;
	}

	public ManualBookingHotel enterCheckOutTime(String checkOutTime){
		enterTextByXpath(prop.getProperty("MB.H.CheckOutTime"),checkOutTime);
		return this;
	}
	public ManualBookingHotel clickToEnterHotelName(){
		clickByXpath(prop.getProperty("MB.H.Click.HotelName"));	
		return this;
	}
	public ManualBookingHotel enterHotelName(String hotelName){	
		enterTextByXpath(prop.getProperty("MB.H.Enter.HotelName"),hotelName);		
		return this;
	}
	public ManualBookingHotel clickAndSelectHotelName(){
		clickByXpath(prop.getProperty("MB.H.Select.HotelName"));
		return this;
	}
	public ManualBookingHotel selectInTransportRequired(String inTransReq){
		if(inTransReq.equalsIgnoreCase("y")){
			clickByXpath(prop.getProperty("MB.H.TransportRequiredIn"));
		}
		return this;
	}
	public ManualBookingHotel selectOutTransportRequired(String outTransReq){
		if(outTransReq.equalsIgnoreCase("y")){
			clickByXpath(prop.getProperty("MB.H.TransportRequiredOut"));
		}
		return this;
	}
	
	public ManualBookingHotel enterExcludeDates (String excludeDate) throws InterruptedException{

		Thread.sleep(2000);
		enterTextByXpath(prop.getProperty("MB.H.sendCheckOutDate"),excludeDate);
		return this;
	}

	
	public ManualBookingHotel enterThirdPartyBookingReference(String TPBR){
		enterTextByXpath(prop.getProperty("MB.H.ThirdPartyBookingReference"),TPBR);
		return this;
	}
	public ManualBookingHotel enterAdminRemarks(String adminRemarks){
		enterTextByXpath(prop.getProperty("MB.H.AdminRemarks"),adminRemarks);
		return this;
	}
	public ManualBookingHotel enterSupplierRemarks(String supplierRemarks){
		enterTextByXpath(prop.getProperty("MB.H.SupplierRemarks"),supplierRemarks);
		return this;
	}
	
	public ManualBookingHotel clickCostInformation(){
		clickByXpath(prop.getProperty("MB.Click.CostInformation"));
		return this;
	}
	
	public ManualBookingHotel enterRoomRate(String roomRate){
		enterTextByXpath(prop.getProperty("MB.H.RoomRate"),roomRate);
		return this;
	}
	
	public ManualBookingHotel clickCurrency(){
		
		clickByXpath(prop.getProperty("MB.H.Click.Currency"));
		return this;
	}

	public ManualBookingHotel enterCurrency(String currency){
		
		enterTextByXpath(prop.getProperty("MB.H.Enter.Currency"),currency);
		return this;
	}

	public ManualBookingHotel clickToSelectCurrency(){
		clickByXpath(prop.getProperty("MB.H.Select.Currency"));
		return this;
	}

	public ManualBookingHotel selectRoomType(String roomType){
		if (roomType.equalsIgnoreCase("standard"))
			clickByXpath(prop.getProperty("MB.H.RoomType.Standard"));
		else
			clickByXpath(prop.getProperty("MB.H.RoomType.Twin"));
		return this;
	}

	public ManualBookingHotel enterNoOfNights(String nights){
		
		enterTextByXpath(prop.getProperty("MB.H.NoOfNights"),nights);
		return this;
	}
	
	public ManualBookingHotel selectCategory(String value){
		selectByxPath(prop.getProperty("MB.H.Click.Category"),value);
		return this;
	}
	
	public ManualBookingHotel enterAmount(String amt){
		enterTextByXpath(prop.getProperty("MB.H.Amount"),amt);
		return this;
	}

	public ManualBookingHotel enterMiscRemarks(String miscRemarks){
		enterTextByXpath(prop.getProperty("MB.H.Remarks"),miscRemarks);
		return this;
	}

	public ManualBookingHotel clickCrewInfo(){
		
		clickByXpath(prop.getProperty("MB.Click.CrewInfo"));
		return this;
	}
	
	public ManualBookingHotel enterCrewID(String id) throws InterruptedException{
		
		enterTextByXpath(prop.getProperty("MB.H.CrewID"),id);
		Thread.sleep(1000);
		return this;
	}
	
	public ManualBookingHotel enterArrivalDuty(String arrivalDuty) throws InterruptedException{
		
		enterTextByXpath(prop.getProperty("MB.H.ArrivalDuty"),arrivalDuty);
		return this;
	}
	
	public ManualBookingHotel enterDepartureDuty(String departureDuty) throws InterruptedException{
		
		enterTextByXpath(prop.getProperty("MB.H.DepartureDuty"),departureDuty);
		return this;
	}
	
	public ManualBookingHotel enterCrewRemarks(String remarks) throws InterruptedException{
		
		enterTextByXpath(prop.getProperty("MB.H.CrewRemarks"),remarks);
		return this;
	}



	public ManualBookingHotel clickSave(){
		clickByXpath(prop.getProperty("Contact.Click.Save"));
		return this;
	}


	/*-----------------------------------------End of Create Hotel------------------------------------------------------------------------------*/	


}






