package pages;



import wrappers.HatsMvpWrappers;

public class HATS extends HatsMvpWrappers{

	public HATS clickContacts(){
		clickByXpath(prop.getProperty("Contact.Click.Contacts"));
		return this;
	}
	
	public HATS clickHotel(){
		clickByLink(prop.getProperty("Contact.Click.Hotel"));
		return this;
	}
	public CreateHotel clickCreate(){
		clickByLink(prop.getProperty("Contact.Click.Create"));
		return new CreateHotel();
	}
	
	
	public HATS clickTransport(){
		clickByLink(prop.getProperty("TContact.Click.Transport"));
		return this;
	}
	
	public HATS clickManualBooking(){
		clickByLink(prop.getProperty("MB.Click"));
		return this;
	}
	
	public  ManualBookingHotel CreateHotelMB(){
		clickByLink(prop.getProperty("MB.Click.Hotel"));
		return new ManualBookingHotel();
	}
	
	public  ManualBookingTransport CreateTransportMB(){
		clickByLink(prop.getProperty("MB.Click.Transport"));
		return new ManualBookingTransport();
	}
	public CreateTransport clickTransportCreate(){
		clickByLink(prop.getProperty("TContact.Click.Create"));
		return new CreateTransport();
	}
	public HATS clickContract(){
		clickByLink(prop.getProperty("Contract.Click"));
		return this;
	}
	
	public HATS clickHotelContract(){
		clickByLink(prop.getProperty("Contract.Hotel.Click"));
		return this;
	}
	public CreateHotelContract clickHotelContractCreate(){
		clickByLink(prop.getProperty("H.Contract.Hotel.Create.Click"));
		return new CreateHotelContract();
	}

	public Object sendHotelName(String hotelName) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	
	
}






