package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import wrappers.HatsMvpWrappers;

public class CreateHotelContract extends HatsMvpWrappers{

	// Create Hotel Contract Actions

	public CreateHotelContract clickHotelName(){
		clickByXpath(prop.getProperty("H.Contract.Hotel.Click"));		
		return this;
	}
	public CreateHotelContract sendHotelName(String hotelName){
		enterTextByXpath(prop.getProperty("H.Contract.Hotel.Send"),hotelName);
		return this;
	}
	public CreateHotelContract selectHotel(){
		clickByXpath(prop.getProperty("H.Contract.Hotel.Select"));
		return this;
	}
	public CreateHotelContract sendRoomCap(String roomCap){
		enterTextByXpath(prop.getProperty("H.Contract.Hotel.RoomCapPerNight.Send"),roomCap);
		return this;
	}
	public CreateHotelContract sendContractStartDate(String CSD){
		enterTextByXpath(prop.getProperty("H.Contract.Hotel.Contract.Start.Date"),CSD);
		return this;
	}
	public CreateHotelContract sendContractEndDate(String CED){
		enterTextByXpath(prop.getProperty("H.Contract.Hotel.Contract.End.Date"),CED);
		return this;
	}
	public CreateHotelContract clickSourceProvider(){
		clickByXpath(prop.getProperty("H.Contract.Hotel.SourceProvider.Click"));
		return this;
	}
	public CreateHotelContract sendSourceProvider(String SP){
		enterTextByXpath(prop.getProperty("H.Contract.Hotel.SourceProvider.Send"),SP);
		return this;
	}
	public CreateHotelContract selectSourceProvider(){
		clickByXpath(prop.getProperty("H.Contract.Hotel.SourceProvider.Select"));
		return this;
	}
	public CreateHotelContract selectCheckinType( ){
		clickByXpath(prop.getProperty("H.Contract.Hotel.CheckInType.24"));
		return this;
	}
	
	public CreateHotelContract sendStandardRoomRate(String RoomRate){
		enterTextByXpath(prop.getProperty("H.Contract.Hotel.StandardRoomRate"),RoomRate);
		return this;
	}
	public CreateHotelContract sendTwinRoomRate(String RoomRate ){
		enterTextByXpath(prop.getProperty("H.Contract.Hotel.TwinRoomRate"),RoomRate);
		return this;
	}
	public CreateHotelContract sendCurrency(String CurrencyCode ){
		enterTextByXpath(prop.getProperty("H.Contract.Hotel.CurrencyCode"),CurrencyCode);
		return this;
	}
	public CreateHotelContract selectHotelTransportReq(String StartTime, String EndTime ){
	
		WebElement HotelTransportReq= driver.findElementByXPath("H.Contract.Hotel.HotelTransportReq");
		if (!HotelTransportReq.isSelected())
		{
		HotelTransportReq.click();
		enterTextByXpath(prop.getProperty("H.Contract.Hotel.TransportStartTime"),StartTime);
		enterTextByXpath(prop.getProperty("H.Contract.Hotel.TransportEndTime"),EndTime);
		}
		
		return this;
	}
	
	public CreateHotelContract selectCategory(String CategoryValue)
	{
		WebElement Category= driver.findElementByXPath("H.Contract.Hotel.MiscCharge");
		Select select = new Select(Category); 
		select.selectByVisibleText(CategoryValue);
		return this;
	}
	public CreateHotelContract checkCommercialNightStop(String commercialNightStop){
		clickByXpath(prop.getProperty("H.Contract.Hotel.CommercialNightStops"));
		return this;
	}
	
	public CreateHotelContract sendAmount(String Amount){
		enterTextByXpath(prop.getProperty("H.Contract.Hotel.Amount"),Amount);
		return this;
	}
	public CreateHotelContract sendRemarks(String Remarks){
		enterTextByXpath(prop.getProperty("H.Contract.Hotel.Remarks"),Remarks);
		return this;
	}
	public CreateHotelContract sendContractDescription(String Description){
		enterTextByXpath(prop.getProperty("H.Contract.Hotel.ContractDesc"),Description);
		return this;
	}
	
	public CreateHotelContract clickSave() throws InterruptedException{
		clickByXpath(prop.getProperty("H.Contract.Hotel.Save"));
		Thread.sleep(2000);
		return this;
	}
	public CreateHotelContract verifyContractCreated(String text,String startDate,String endDate){
		verifyHotelContract(text,startDate,endDate);

		return this;

	}
			
}






