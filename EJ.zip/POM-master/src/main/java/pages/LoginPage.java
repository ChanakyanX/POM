package pages;

import wrappers.HatsMvpWrappers;

public class LoginPage extends HatsMvpWrappers{
	public HATS clickLogin(){
		clickByXpath(prop.getProperty("Login.LoginButton.Class"));
		return new HATS();
	}
}
